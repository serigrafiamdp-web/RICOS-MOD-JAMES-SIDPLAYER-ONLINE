SPOTYSID BETA 1 — OFFLINE CSDb EDITION
======================================

Extract this ZIP and double-click index.html in a browser.
No internet access or installation is needed to play the three included
SID sample tracks or load your own local .sid files.

Included in this compact edition:
- Three local SID samples
- Open or drag-drop local SID files
- Play/pause, stop, next/previous track and subtunes
- AUTO with selectable timer, voice controls, filter, oscilloscope colors
- Visible button: OPEN FULL SPOTYSID ONLINE

The full online version offers more functions including HVSC browsing,
community playlists, rankings and publishing:
https://serigrafiamdp-web.github.io/RICOS-MOD-JAMES-SIDPLAYER-ONLINE/

This is a small functional HTML distribution, not the development repo.

CREDITS
James / Jojati — Original SID Player
RICO / RicoSerigrafia — SpotySid continued development
SID samples and TinySID remain credited to their original authors.
TinySID retains copyright and license notices inside index.html.
Released for CSDb archival purposes, November 2026.
